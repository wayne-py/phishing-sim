SMTP_SERVER = 'smtp.gmail.com'
SMTP_PORT = 587
EMAIL_ADDRESS = 'youremail@example.com'
EMAIL_PASSWORD = 'yourpassword'
TRACKING_URL = 'http://localhost:5000/track?user='
